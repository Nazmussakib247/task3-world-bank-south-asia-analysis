# Task 6 — South Asia Development Indicators Capstone

Prepared by Nazmus Sakib. This capstone combines data quality validation, exploratory analysis, visual storytelling, a documented machine-learning workflow, and time-block holdout evaluation using World Bank World Development Indicators for Bangladesh, India, Nepal, Pakistan, and Sri Lanka (2000–2024).

## Reproduce

From the repository root, install the capstone dependencies and run:

```bash
pip install -r task6_capstone/requirements.txt
python task6_capstone/capstone_analysis.py
```

The script reads `data/south_asia_wdi_2000_2024.csv`, validates panel dimensions and quality, fits a Ridge regression using country indicators, standardized year, and standardized log GDP per capita, then writes country summaries, predictions, model metrics, validation metadata, and charts to this folder's `outputs/` and `figures/` directories.

## Evaluation design and guardrails

Training data are 2000–2019 (100 records); the held-out block is 2020–2024 (25 records, five per country). Baselines are each country's training-period mean and its last observed 2019 life expectancy. The model is a retrospective held-out estimation exercise: test rows include contemporaneous GDP-per-capita values. It is not a prospective forecast, causal model, or deployment-ready health decision system. The small five-country panel and time dependence limit generalization.

## Contents

- `capstone_analysis.py` — end-to-end reproducible validation, analysis, model and chart generation.
- `outputs/` — country summaries, held-out predictions, aggregate and country-level metrics, validation scope.
- `figures/` — source analysis charts and two holdout evaluation charts.
- `Task_6_Final_Capstone_Report.docx` — stakeholder report.

## Data attribution

GDP per capita (constant 2015 US$), World Bank indicator `NY.GDP.PCAP.KD`; life expectancy at birth, total years, `SP.DYN.LE00.IN`. World Bank WDI data are subject to revisions. See the repository's `DATA_ATTRIBUTION.txt` and the indicator links in the capstone report. Correlations and model performance are descriptive and do not establish causation.
