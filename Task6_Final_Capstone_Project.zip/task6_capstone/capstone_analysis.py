"""Reproduce the Task 6 South Asia development-indicators capstone.

Run from the project root: python capstone_analysis.py
Needs: pandas, numpy, matplotlib, scikit-learn
The model is a retrospective time-block holdout estimation exercise, not a
prospective forecast or causal model. Training uses years <= 2019; evaluation
uses 2020-2024 with contemporaneous GDP as an input feature.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

ROOT = Path(__file__).resolve().parent
DATA = ROOT.parent / "data" / "south_asia_wdi_2000_2024.csv"
if not DATA.exists():
    DATA = ROOT / "data" / "south_asia_wdi_2000_2024.csv"
OUT = ROOT / "outputs"
FIG = ROOT / "figures"
OUT.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)
EXPECTED_COUNTRIES = {"Bangladesh", "India", "Nepal", "Pakistan", "Sri Lanka"}

def main():
    df = pd.read_csv(DATA)
    required = {"country", "year", "gdp_pc_2015_usd", "life_expectancy_years"}
    missing_columns = sorted(required - set(df.columns))
    assert not missing_columns, f"Missing columns: {missing_columns}"
    assert len(df) == 125, f"Expected 125 rows, got {len(df)}"
    assert set(df.country) == EXPECTED_COUNTRIES
    assert df.year.min() == 2000 and df.year.max() == 2024
    assert not df.duplicated(["country", "year"]).any()
    assert not df[["gdp_pc_2015_usd", "life_expectancy_years"]].isna().any().any()
    assert (df.gdp_pc_2015_usd > 0).all()
    assert df.life_expectancy_years.between(0, 120).all()

    # Country endpoint summaries and descriptive associations
    summaries = []
    for country, g in df.groupby("country", sort=True):
        g = g.sort_values("year")
        first = g.loc[g.year.eq(2000)].iloc[0]
        last = g.loc[g.year.eq(2024)].iloc[0]
        summaries.append({
            "country": country,
            "gdp_pc_2000_2015_usd": first.gdp_pc_2015_usd,
            "gdp_pc_2024_2015_usd": last.gdp_pc_2015_usd,
            "gdp_pc_change_pct": 100 * (last.gdp_pc_2015_usd / first.gdp_pc_2015_usd - 1),
            "life_2000_years": first.life_expectancy_years,
            "life_2024_years": last.life_expectancy_years,
            "life_change_years": last.life_expectancy_years - first.life_expectancy_years,
            "within_country_pearson_r": g.gdp_pc_2015_usd.corr(g.life_expectancy_years),
        })
    pd.DataFrame(summaries).to_csv(OUT / "country_summary.csv", index=False, float_format="%.4f")

    # Strict time-block holdout: training <=2019; test 2020-2024, all countries.
    train = df[df.year <= 2019].copy()
    test = df[df.year >= 2020].copy()
    assert len(train) == 100 and len(test) == 25
    train["log_gdp"] = np.log(train.gdp_pc_2015_usd)
    test["log_gdp"] = np.log(test.gdp_pc_2015_usd)
    X_train = train[["country", "year", "log_gdp"]]
    y_train = train.life_expectancy_years
    X_test = test[["country", "year", "log_gdp"]]
    y_test = test.life_expectancy_years

    encoder = ColumnTransformer([
        ("country", OneHotEncoder(handle_unknown="ignore"), ["country"]),
        ("numeric", StandardScaler(), ["year", "log_gdp"]),
    ])
    model = make_pipeline(encoder, Ridge(alpha=1.0))
    model.fit(X_train, y_train)
    test["ridge_prediction_years"] = model.predict(X_test)
    # Two transparent reference baselines
    means = train.groupby("country").life_expectancy_years.mean()
    last_values = train.sort_values("year").groupby("country").tail(1).set_index("country").life_expectancy_years
    test["training_country_mean_prediction_years"] = test.country.map(means)
    test["last_observed_prediction_years"] = test.country.map(last_values)
    test["ridge_error_years"] = test.ridge_prediction_years - test.life_expectancy_years
    test.to_csv(OUT / "heldout_predictions_2020_2024.csv", index=False, float_format="%.4f")

    predictions = {
        "Test period actual": y_test,
        "Country training mean": test.training_country_mean_prediction_years,
        "Last observed (2019)": test.last_observed_prediction_years,
        "Ridge (country + year + log GDP)": test.ridge_prediction_years,
    }
    rows = []
    for name, pred in predictions.items():
        if name == "Test period actual":
            continue
        rows.append({"model": name, "mae_years": mean_absolute_error(y_test, pred),
                     "rmse_years": mean_squared_error(y_test, pred) ** 0.5,
                     "r2_test": r2_score(y_test, pred)})
    pd.DataFrame(rows).to_csv(OUT / "holdout_model_metrics.csv", index=False, float_format="%.4f")
    per_country = []
    for country, g in test.groupby("country", sort=True):
        per_country.append({"country": country, "test_n": len(g),
                            "ridge_mae_years": mean_absolute_error(g.life_expectancy_years, g.ridge_prediction_years),
                            "ridge_rmse_years": mean_squared_error(g.life_expectancy_years, g.ridge_prediction_years)**0.5})
    pd.DataFrame(per_country).to_csv(OUT / "holdout_metrics_by_country.csv", index=False, float_format="%.4f")

    # Plot observed vs fitted held-out values and errors by country
    fig, ax = plt.subplots(figsize=(7.2, 5.7))
    palette = dict(zip(sorted(EXPECTED_COUNTRIES), plt.cm.tab10.colors[:5]))
    for country, g in test.groupby("country", sort=True):
        ax.scatter(g.life_expectancy_years, g.ridge_prediction_years, label=country,
                   color=palette[country], s=42, alpha=.82, edgecolor="white", linewidth=.4)
    lo = min(test.life_expectancy_years.min(), test.ridge_prediction_years.min()) - .5
    hi = max(test.life_expectancy_years.max(), test.ridge_prediction_years.max()) + .5
    ax.plot([lo, hi], [lo, hi], linestyle="--", color="#40566b", linewidth=1)
    ax.set(xlabel="Observed life expectancy (years)", ylabel="Ridge estimate (years)",
           title="Held-out observations, 2020–2024")
    ax.legend(frameon=False, ncol=2); ax.grid(alpha=.2); fig.tight_layout()
    fig.savefig(FIG / "heldout_observed_vs_estimated.png", dpi=180); plt.close(fig)

    metrics = pd.read_csv(OUT / "holdout_model_metrics.csv")
    fig, ax = plt.subplots(figsize=(8.2, 4.6))
    q = metrics.sort_values("mae_years", ascending=False)
    bars = ax.barh(q.model, q.mae_years, color=["#e29a31" if "Ridge" in s else "#258a96" for s in q.model])
    for bar, val in zip(bars, q.mae_years):
        ax.text(val + .02, bar.get_y() + bar.get_height()/2, f"{val:.2f} y", va="center", fontsize=9)
    ax.set(xlabel="Mean absolute error (years; lower is better)", title="Time-block holdout model comparison")
    ax.set_xlim(0, max(q.mae_years)*1.22); ax.grid(axis="x", alpha=.2); fig.tight_layout()
    fig.savefig(FIG / "holdout_mae_comparison.png", dpi=180); plt.close(fig)

    validation = {
        "rows": int(len(df)), "countries": sorted(df.country.unique().tolist()),
        "years": [int(df.year.min()), int(df.year.max())],
        "training_rows": int(len(train)), "test_rows": int(len(test)),
        "training_period": "2000-2019", "test_period": "2020-2024",
        "missing_values": int(df[["gdp_pc_2015_usd", "life_expectancy_years"]].isna().sum().sum()),
        "duplicate_country_years": int(df.duplicated(["country", "year"]).sum()),
        "model": "Ridge regression, alpha=1.0; country one-hot + standardized year + standardized log GDP per capita",
        "interpretation": "Retrospective time-block holdout estimation, not a prospective forecast or causal model; test inputs include contemporaneous GDP per capita."
    }
    (OUT / "validation_and_scope.json").write_text(json.dumps(validation, indent=2)+"\n")
    print(pd.read_csv(OUT / "holdout_model_metrics.csv").to_string(index=False))
    print("Wrote outputs to", OUT, "and figures to", FIG)

if __name__ == "__main__":
    main()
